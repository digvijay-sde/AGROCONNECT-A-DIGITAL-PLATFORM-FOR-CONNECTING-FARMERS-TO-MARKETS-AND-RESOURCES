import React from "react";

function Assistant() {
  return <div>Assistant</div>;
}

export default Assistant;
