import React from 'react'

const Footer = () => {
  return (
      <div className='bg-primary text-light p-3'>
          <h4 className='text-center'>Catering all farming needs &copy; Agri Connect 🔗</h4>
      </div>
  )
}

export default Footer